<!DOCTYPE html>
<html>

<head>
    <title>Car Rental</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="./bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="./bootstrap/css/style.css">
    <link rel="stylesheet" href="./bootstrap/css/w3.css">
    <script type="text/javascript" src="./bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="./javascript/jquery-3.3.1.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="../WebLab/index.html">CarGet</a>
            </div>
            <ul class="nav navbar-nav">
                <li>
                    <a href="../WebLab/index.html">HOME
                        <i class="fas fa-home"></i>
                    </a>
                </li>
                <li>
                    <a href="link/FAQ.html">FAQ</a>
                </li>
            </ul>

            <div class="col-sm-5 col-md-5">
                <div class="input-group">
                    <form class="navbar-form" role="search">
                        <input type="text" class="form-control" placeholder="Search" name="q">
                        <div class="input-group-btn">
                            <button class="btn btn-default" type="submit">
                                <i class="glyphicon glyphicon-search"></i>
                            </button>
                            <button type="button" class="btn btn-default dropdown-toggle" onclick="document.getElementById('id01').style.display='block'">
                                <span class="caret"></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="link/User/ClientSign-Up.html">
                        <span class="glyphicon glyphicon-user"></span> Sign Up</a>
                </li>
                <li>
                    <a href="link/Sign-in.html">
                        <span class="glyphicon glyphicon-log-in"></span> Login</a>
                </li>
            </ul>
        </div>
    </nav>
    <!-- CARGET BUTTON-->
    <div class="w3-container">
        <div id="id01" class="w3-modal">
            <div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width:600px">

                <div class="w3-center">
                    <br>
                    <span onclick="document.getElementById('id01').style.display='none'" class="w3-button w3-xlarge w3-hover-red w3-display-topright"
                        title="Close Modal">&times;</span>
                </div>

                <form class="w3-container" action="/action_page.php">
                    <div class="w3-section">

                        <div class="form-group col-md-10 col-sm-offset-1">
                            <br>
                            <form class="" method="" role="">
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                        <!--START OF THE PRICE RANGE -->
                                        <h4>Price Range</h4>
                                        <div class="container-fluid small">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" " checked>
                                                <label class="form-check-label" for=" ">
                                                    Any
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                                <label class="form-check-label" for=" ">
                                                    2,500 and below
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                                <label class="form-check-label" for=" ">
                                                    2,500 - 5,000
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                                <label class="form-check-label" for=" ">
                                                    5,000 - 7,500
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                                <label class="form-check-label" for=" ">
                                                    7,500 - 10,000
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                                <label class="form-check-label" for=" ">
                                                    10,000 and Above
                                                </label>
                                            </div>
                                        </div>
                            </form>
                            <!--END OF THE PRICE RANGE -->
                            <form class="" method="" role="">
                                <!--START OF THE CAR BRAND -->
                                <h4>Car Brand</h4>
                                <div class="container-fluid small">
                                    <div class="form-group">
                                        <select class="form-control" id="">
                                            <option>Toyota</option>
                                            <option>Mitsubishi</option>
                                            <option>Ferrari</option>
                                            <option>Ford</option>
                                            <option>Subarru</option>
                                        </select>
                                    </div>
                                </div>
                            </form>
                            <!--END OF THE CAR BRAND -->
                            <form class="" method="" role="">
                                <!--START OF THE CAR FEATURES -->
                                <h4>Car Transmission Types</h4>
                                <div class="container-fluid small">
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                        <label class="form-check-label" for=" ">
                                            Automatic Transmission
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="gridRadios" id=" " value=" ">
                                        <label class="form-check-label" for=" ">
                                            Manual Transmission
                                        </label>
                                    </div>
                                </div>
                                <!--END OF THE CAR FEATURES -->
                                </div>
                                </div>
                            </form>
                            <!-- END OF THE DATE RANGE PICKER-->
                        </div>
                        <div class="form-group">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary">
                                    Search
                                </button>
                            </div>
                        </div>
                    </div>
            </div>
            </form>

        </div>
    </div>

    <section class="header">
    </section>

    <section class="body">
        <div class="container body_container col-sm-10 col-sm-offset-1">
            <div class="body_title">
                <center>
                    VEHICLES
                </center>
            </div>
        <form action="link/insert.php" method="post">
            <center>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="row">
                                <div class="col-sm-3 body_item">
                                    <img src="./images/7.jpg" class="body_img">

                                    <br/>
                                    <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                    <input name="sp" type="text" placeholder="Provider: Mr. Mark Bambico" class="body_read" readonly>
                                    <input name="model" type="text" placeholder="FORD F-150" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/1.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 4" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Julius Payaket" class="body_read" readonly>
                                    <input type="text" placeholder="TOYOTA CAMRY" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/2.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Ms. Lovelyn Paris" class="body_read" readonly>
                                    <input type="text" placeholder="HONDA ACCORD" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/3.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 8" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Luger Pit-og" class="body_read" readonly>
                                    <input type="text" placeholder="CHEVROLET TRAVERSE" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="row">
                                <div class="col-sm-3 body_item">
                                    <img src="./images/4.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Mark Bambico" class="body_read" readonly>
                                    <input type="text" placeholder="SUBARU CROSSTREK" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/5.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Mark Bambico" class="body_read" readonly>
                                    <input type="text" placeholder="VOLKSWAGEN TIGUAN" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/6.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 8" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Julius Payaket" class="body_read" readonly>
                                    <input type="text" placeholder="BMW X3" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/8.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 10" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Luger Pit-og" class="body_read" readonly>
                                    <input type="text" placeholder="HYUNDAI CRETA" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="row">
                                <div class="col-sm-3 body_item">
                                    <img src="./images/9.png" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Julius Martinez" class="body_read" readonly>
                                    <input type="text" placeholder="HONDA AMAZE" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/10.png" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 4" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Lorence Lopez" class="body_read" readonly>
                                    <input type="text" placeholder="HYUNDAI i20 ACTIVE" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/11.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 4" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Mark Bambico" class="body_read" readonly>
                                    <input type="text" placeholder="MINI COUNTRYMAN" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>

                                <div class="col-sm-3 body_item">
                                    <img src="./images/12.jpg" class="body_img">

                                    <br/>
                                        <input name="cap" type="text" placeholder="CAPACITY: 5" class="body_read" readonly>
                                        <input name="sp" type="text" placeholder="Provider: Mr. Mark Bambico" class="body_read" readonly>
                                    <input type="text" placeholder="FORD FREESTYLE" class="body_read" readonly>
                                    <button class="body_button" onclick="window.location.href='link/transaction.html'">RENT CAR</button>
                                </div>
                            </div>
                        </div>

                        <ol class="carousel-indicators">
                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                            <li data-target="#myCarousel" data-slide-to="1"></li>
                            <li data-target="#myCarousel" data-slide-to="2"></li>
                        </ol>

                        <br/>

                        <button id="carousel_button">VIEW MORE</button>
                    </div>
                </div>
            </center>
        </form>
        </div>
    </section>

    <section class="footer">
        <div class="footer_bottom col-sm-10 col-sm-offset-1">
            <hr>
            <div class="row">
                <div class="col-sm-3">
                    <a href="https://www.facebook.com/aikavien.dayrit" id="footer_link">© THE CREATOR.2018</a>
                </div>

                <div class="col-sm-3 col-sm-offset-6">
                    SLU FINAL WEBTECH REQUIREMENT
                </div>
            </div>
        </div>
    </section>


</body>

</html>