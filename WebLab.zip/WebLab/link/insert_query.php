<?php
$db_server = "localhost";
$db_username = "root";
$db_password = "";
$db_database = "cars";
// database name variables and the value in the input type
$pickuplocation=$_POST['pul'];
$pickupdate=$_POST['pud'];
$pickuptime=$_POST['put'];
$returndate=$_POST['rd'];
$returntime=$_POST['rt'];

$conn = new PDO("mysql:host=$db_server;dbname=$db_database", $db_username, $db_password);

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// table name in the database and the variables
$sql = "INSERT INTO transactions (pickuplocation, pickupdate, pickuptime, returndate, returntime) 
VALUES ('$pickuplocation', '$pickupdate', '$pickuptime', '$returndate', '$returntime')";

$conn->exec($sql);
echo "<script>alert('Account successfully added!'); window.location='transaction.php'</script>";
?>