<?php
$db_server = "localhost";
$db_username = "root";
$db_password = "";
$db_database = "cars";
// database name variables and the value in the input type
$capacity=$_POST['cap'];
$serviceprovider=$_POST['sp'];
$carmodel=$_POST['model'];

function testdb_connect ($db_server, $db_username, $db_password){
	$conn = new PDO("mysql:host=$db_server;dbname=$db_database", $db_username, $db_password);
	return $conn;
}

try {
    $conn = testdb_connect ($db_server, $db_username, $db_password);
    echo 'Connected to database';
} catch(PDOException $e) {
    echo $e->getMessage();
}
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// table name in the database and the variables
$sql = "INSERT INTO car_details (capacity, serviceprovider, carmodel) 
VALUES ('$capacity', '$serviceprovider', '$carmodel')";

$conn->exec($sql);
echo "<script>alert('Account successfully added!'); window.location='transaction.php'</script>";
?>