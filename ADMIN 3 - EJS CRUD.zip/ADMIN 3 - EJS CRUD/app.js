const express = require('express');
const http = require('http');
const app = express();
const bodyParser = require('body-parser');
const db = require('./model/dbconnect');

const dateFormat = require('dateformat');

app.set('view engine', 'ejs');
const siteTitle = "CarGet Car Rentals"

//bodyparser shit
app.use(bodyParser.urlencoded({
    extended: true
}));

//bootstrap shit etc
app.use('/js', express.static(__dirname + '/node_modules/tether/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/jquery/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/css'))

//port shit
app.listen(4000, function () {
    console.log("Server running in port 4000");
})

//CLIENT OPTION MENU
app.get('/', function (req, res) {
    res.render('pages/user_options', {});
});

//CLIENT REGISTRATION - displays form
app.get('/registration', function (req, res) {
    res.render('pages/client_registration', {
        items: ''

    });

});
//CLIENT REGISTRATION - POST METHOD
app.post('/registration', function (req, res) {
    let sql = "INSERT INTO customer(FirstName,LastName,Gender,Email,PhoneNumber,Password,Age,Role) VALUES (";
    sql += " '" + req.body.FirstName + "',";
    sql += " '" + req.body.LastName + "',";
    sql += " '" + req.body.Gender + "',";
    sql += " '" + req.body.Email + "',";
    sql += " '" + req.body.PhoneNumber + "',";
    sql += " '" + req.body.Password + "',";
    sql += " '" + req.body.Age + "',";
    sql += " '" + req.body.Role + "')";
    
    let query = db.query(sql, (err, results) => {
        console.log('this query error::', err)
        res.redirect('/')        
    })
})

//ALL CLIENT ACCOUNTS
app.get('/accounts', function (req, res) {
    let sql = 'SELECT * FROM customer WHERE NOT Role = "Administrator"';
    let query = db.query(sql, (err, results) => {
        res.render('pages/accounts', {
            items: results
        });
    });

});

//CUSTOMER ACCOUNTS (pending)
app.get('/accounts/customer', function (req, res) {
    let sql = 'SELECT * FROM customer WHERE Status = "Pending" AND Role = "Customer"';
    let query = db.query(sql, (err, results) => {
        res.render('pages/cus_accounts', {
            items: results
        });
    });

});

//CUSTOMER ACCEPTED UPDATE ACCOUNTS
app.get('/accounts/customer/:Status', function (req, res) {
    //connection.query("SELECT * FROM customer WHERE ")
})


//SP ACCOUNTS (pending)
app.get('/accounts/sp', function (req, res) {
    let sql = 'SELECT * FROM customer  WHERE Status = "Pending" AND Role = "Service Provider" ';
    let query = db.query(sql, (err, results) => {
        res.render('pages/sp_accounts', {
            items: results
        })
    });
});

//TRANSACTION